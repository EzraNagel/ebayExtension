﻿namespace JokesWebApp.Models
{
    public class Jokes
    {
        public int Id { get; set; }
        public string JokeQuestion { get; set; }
        public string JokeAnswer { get; set; }

        public Jokes()
        {

        }
    }

}
